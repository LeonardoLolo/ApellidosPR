README

Titulo: Reimplementación de apellidosPR utilizando datos a escala de unidad electoral

Autores:
	Leonardo Morales Casillas 
	Adrián R. Roldán Richards

Curso: CDAT3040-001
Prof. Elio Ramos Colón
Este proyecto es una aplicación interactiva que genera gráficos detallados sobre un apellido introducido por el usuario. Utiliza Flask y Dash para la creación de la interfaz web, junto con bibliotecas de visualización como Plotly. Los datos se manejan a partir de archivos CSV y GeoJSON para ofrecer una herramienta útil y fácil de usar para explorar la historia y la distribución de un apellido específico.
Se pueden encontrar las próximas gráficas e interfaces:
Input de Apellido: Permite al usuario introducir el apellido sobre el cual se generarán los gráficos.
Range Slider: Permite escoger el rango de años para comparar mejor entre fechas.
Dashboard de Estadísticas del Apellido: Presenta un resumen interactivo de las estadísticas del apellido introducido.
Gráfica de Barras Horizontales: Muestra la cantidad de personas con el apellido en los primeros 10 municipios con más personas del mismo apellido.
Gráfico Circular (Pie Chart): Representa el porcentaje de distribución de personas con el apellido en los 10 municipios mostrados en la gráfica de barras horizontales.
Gráfica de Barras por Generaciones: Muestra la cantidad de personas con el apellido en el eje Y y los nombres de las generaciones en el eje X.
Gráfico Circular (Pie Chart) por Generaciones: Muestra el porcentaje de personas con el apellido por cada generación.
Gráfica Lineal: Ilustra el aumento y descenso del apellido a lo largo de los años.
Mapa Coroplético: Muestra los municipios y la frecuencia del apellido en cada municipio.
Dashboard de Apellidos Similares: Muestra información sobre 5 apellidos similares al apellido introducido.
Tecnologías Utilizadas:
Flask: Para el desarrollo del backend.
Dash: Para crear la interfaz web interactiva.
Plotly: Para la generación de gráficos.
Archivos CSV: Para la manipulación y análisis de datos.
Archivos GeoJSON: Para la visualización de datos geográficos.
La información generada por este proyecto es útil para individuos curiosos sobre sus raíces familiares. Se demuestra cómo las tecnologías de programación pueden transformar datos en información valiosa y accesible, ayudando a los usuarios a explorar y comprender mejor el contexto histórico y actual de su apellido.
Gracias por utilizar nuestra aplicación. Esperamos que encuentres información proporcionada interesante y útil. ¡Buena suerte y feliz exploración!

